using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Pages.Shared
{
    public class ContactUsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
